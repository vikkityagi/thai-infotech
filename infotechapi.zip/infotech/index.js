// index.js
const express = require('express');
const db = require('./db'); // Importing the database connection
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const cors = require('cors');

// Middleware to parse JSON request bodies
app.use(bodyParser.json());

// Enable CORS for all routes
app.use(cors());

app.get('/', (req, res) => {
    res.send('Hello World!');
  });

app.post('/infotech', async (req, res) => {
    const items = req.body;
  
    if (!Array.isArray(items)) {
      return res.status(400).send('Input should be a list of JSON objects');
    }
  
    const insertQuery = `
      INSERT INTO infotech (item_id, strain_id, quantity, uom_id, cost, supplier_id, lot_name)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
    `;
  
    const client = await db.pool.connect();
  
    try {
      await client.query('BEGIN');
      for (const item of items) {
        const { item_id, strain_id, quantity, uom_id, cost, supplier_id, lot_name } = item;
        await client.query(insertQuery, [item_id, strain_id, quantity, uom_id, cost, supplier_id, lot_name]);
      }
      await client.query('COMMIT');
      res.status(201).send('Data inserted successfully');
    } catch (error) {
      await client.query('ROLLBACK');
      console.error('Error inserting data:', error);
      res.status(500).send('Internal Server Error');
    } finally {
      client.release();
    }
  });



// Ensure table is created before starting the server
const startServer = async () => {
  try {
    await db.createTable(); // Create the table
    app.listen(port, () => {
      console.log(`Example app listening on port ${port}`);
    });
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1); // Exit the process with a failure code
  }
};




startServer();
