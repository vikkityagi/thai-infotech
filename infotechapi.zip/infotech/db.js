// db.js
const { Pool } = require('pg');

// Configure the connection to your PostgreSQL database
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'infotech',
  password: 'postgres',
  port: 5432, // default PostgreSQL port
});

// Function to create the infotech table
const createTableQuery = `
  CREATE TABLE IF NOT EXISTS infotech (
    category_id SERIAL PRIMARY KEY,
    item_id INTEGER NOT NULL,
    strain_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    uom_id INTEGER NOT NULL,
    cost DECIMAL(10, 2) NOT NULL,
    supplier_id INTEGER NOT NULL,
    lot_name VARCHAR(255) NOT NULL
  );
`;

async function createTable() {
  try {
    await pool.query(createTableQuery);
    console.log('infotech table created successfully');
  } catch (error) {
    console.error('Error creating infotech table:', error);
  }
}

module.exports = {
  pool, // Export the pool here
  query: (text, params) => pool.query(text, params),
  createTable,
};
