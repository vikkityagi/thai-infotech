import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {provideNativeDateAdapter} from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';



@Component({
  selector: 'app-basic-detail',
  standalone: true,
  imports: [MatSelectModule,ReactiveFormsModule,MatInputModule,MatDatepickerModule,MatButtonModule],
  providers: [provideNativeDateAdapter()],
  templateUrl: './basic-detail.component.html',
  styleUrl: './basic-detail.component.css'
})
export class BasicDetailComponent implements OnInit {

  basicDetailFormGroup: any = FormGroup;
  companies: any[] = [{id:1,name: 'Oriental Plantation Company Limited'}];
  storeList: any[] = [{id:1,name:'Grow Room (Mentley Korat)'},{id:2,name:'Waster Store-1'},{id:3,name:'Waster Store-2'}];

  @Output() nextEmit = new EventEmitter<boolean>();

  
  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initForm();
    this.basicDetailFormGroup.get('document_number')?.setValue(this.generateRandomNumber());
  }

  private initForm(): void {
    this.basicDetailFormGroup = this.fb.group({
      company: ['',[Validators.required]],
      date: ['',[Validators.required]],
      store: ['',[Validators.required]],
      document_number: ['',[Validators.required]],
      text_area: ['',[Validators.required]]
    });
  }

  private generateRandomNumber(): number {
    return Math.floor(100000 + Math.random() * 900000);
  }

  public resetFormGroup(): void {
    this.basicDetailFormGroup.reset();
  }

  public getFormGroupValue(): any {
    return this.basicDetailFormGroup.value;
  }

  next(): void {
    if (this.basicDetailFormGroup.valid) {
      this.nextEmit.emit(this.basicDetailFormGroup.value);
    }else {
      this.basicDetailFormGroup.markAllAsTouched(); // This will highlight the invalid fields
    }
  }

}
