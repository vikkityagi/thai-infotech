import { CommonModule } from '@angular/common';
import { Component, Input, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { BasicDetailComponent } from '../basic-detail/basic-detail.component';
import { AuthService } from '../../auth.service';


@Component({
  selector: 'app-create-grn',
  standalone: true,
  imports: [MatCardModule, ReactiveFormsModule, MatFormFieldModule, MatIconModule, CommonModule, MatInputModule, MatSelectModule, MatButtonModule],
  templateUrl: './create-grn.component.html',
  styleUrl: './create-grn.component.css'
})
export class CreateGrnComponent {

  grnFormGroup: any = FormGroup;
  categories: any[] = [{ id: 1, name: 'Category-1' }, { id: 2, name: 'Category-2' }, { id: 3, name: 'Category-3' }];
  itemList: any[] = [{ id: 1, name: 'Shirt' }, { id: 2, name: 'Detergent' }, { id: 3, name: 'Shop' }, { id: 4, name: 'Toy' }];
  strains: any[] = [{ id: 1, name: 'strains-1' }, { id: 2, name: 'strains-2' }, { id: 3, name: 'strains-3' }, { id: 4, name: 'strains-4' }];
  uomList: any[] = [{ id: 1, name: 'uom-1' }, { id: 2, name: 'uom-2' }, { id: 3, name: 'uom-3' }, { id: 4, name: 'uom-4' }];
  suppliers: any[] = [{ id: 1, name: 'supplier-1' }, { id: 2, name: 'supplier-2' }, { id: 3, name: 'supplier-3' }, { id: 4, name: 'supplier-4' }];
  costList: any[] = [{ id: 1, value: '780' }, { id: 2, value: '800' }, { id: 3, value: '820' }, { id: 4, value: '850' }];

  @Input() basicDetailComponentValue: any;



  constructor(private fb: FormBuilder, private authService: AuthService) {
    this.grnFormGroup = this.fb.group({
      items: this.fb.array([])
    });
    this.addItem();
  }

  get items() {
    return this.grnFormGroup.get('items') as FormArray;
  }


  addItem() {
    const itemGroup = this.fb.group({
      category_id: ['', [Validators.required]],
      item_id: ['', [Validators.required]],
      strain_id: ['', [Validators.required]],
      quantity: ['', [Validators.required]],
      uom_id: ['', [Validators.required]],
      cost: ['', [Validators.required]],
      supplier_id: ['', [Validators.required]],
      lot_name: ['', [Validators.required]]
    });
    this.items.push(itemGroup);
  }

  removeStudent(index: number) {
    this.items.removeAt(index);
  }

  onSubmit() {
    if(this.grnFormGroup.valid){
      this.authService.onSubmitInfotech(this.items.value).subscribe({
        next: (data) => {
          alert('Submit done');
        },
        error: (error) => {
          console.log(error);
        },
        complete: () => {
  
        }
      })
    }
    
  }



}
