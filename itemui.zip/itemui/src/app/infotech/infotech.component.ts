import { Component, ViewChild } from '@angular/core';
import { BasicDetailComponent } from './basic-detail/basic-detail.component';
import { CreateGrnComponent } from './create-grn/create-grn.component';
import { MatStepper, MatStepperModule } from '@angular/material/stepper';

@Component({
  selector: 'app-infotech',
  standalone: true,
  imports: [
    MatStepperModule,
    BasicDetailComponent,
    CreateGrnComponent
  ],
  templateUrl: './infotech.component.html',
  styleUrl: './infotech.component.css'
})
export class InfotechComponent {
  sendNextData: any;
  @ViewChild('stepper') private myStepper!: MatStepper;
  isFormValid: boolean = false;





  handleNextEmit(data: any) {
    this.sendNextData = data;
    if (this.sendNextData != null)
      this.isFormValid = true;
      this.myStepper.next();
  }



}

