import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InfotechComponent } from './infotech.component';

describe('InfotechComponent', () => {
  let component: InfotechComponent;
  let fixture: ComponentFixture<InfotechComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InfotechComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InfotechComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
