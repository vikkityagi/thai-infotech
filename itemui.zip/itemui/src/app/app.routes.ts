import { Routes } from '@angular/router';
import { InfotechComponent } from './infotech/infotech.component';

export const routes: Routes = [
    {path: '',component:InfotechComponent    }
];
